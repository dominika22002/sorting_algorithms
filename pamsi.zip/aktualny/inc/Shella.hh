#ifndef SHELLA_HH
#define SHELLA_HH

#include <vector>
#include <iostream>
#include <math.h>
#include <memory>
#include <ctime>

using namespace std;
/*
  for(h = 1; h < N; h = 3 * h + 1);
  h /= 9;
  if(!h) h++; // istotne dla małych N, dla większych można pominąć!

// Sortujemy

  while(h)
  {
    for(j = N - h - 1; j >= 0; j--)
    {
      x = d[j];
      i = j + h;
      while((i < N) && (x > d[i]))
      {
        d[i - h] = d[i];
        i += h;
      }
      d[i - h] = x;
    }
    h /= 3;
  }
  */
template <int rozmiar1>
int sortuj_sh(int tablica[], int pierwszy, int ostatni)
{
    int h = 1, x = 0, i = 0;

    while (h < rozmiar1)
    {
        h = 3 * h + 1;
    }
    h = h / 9;
    while (h)
    {
        for (int j = rozmiar1 - h - 1; j >= 0; j--)
        {
            x = tablica[j];
            i = j + h;
            while ((i < rozmiar1) && (x > tablica[i]))
            {
                tablica[i - h] = tablica[i];
                i += h;
            }
            tablica[i - h] = x;
        }
        h /= 3;
    }
    return 0;
}

template <int rozmiar1>
int sortowanie_shella(int *wektor[rozmiar1])
{
    clock_t start, stop;
    start = clock();
    for (int i = 0; i < 100; i++)
    {
        sortuj_sh<rozmiar1>(wektor[i], 0, rozmiar1 - 1);
    }
    stop = clock();
    unsigned long int czas = 1000 * (stop - start) / CLOCKS_PER_SEC;
    return czas;
}

#endif
