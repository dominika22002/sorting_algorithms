#ifndef QUICKSORT_HH
#define QUICKSORT_HH

#include <vector>
#include <iostream>
#include <math.h>
#include <memory>
#include <ctime>

using namespace std;

// template <int rozmiar1>
    int sortuj_q(int tablica[], int pierwszy, int ostatni)
    {
        int i = pierwszy - 1;
        int j = ostatni + 1;
        int pivot = tablica[(pierwszy + ostatni) / 2];
        while (1)
        {
            while (pivot > tablica[++i])
                ;
            while (pivot < tablica[--j])
                ;
            if (i <= j)
                swap(tablica[i], tablica[j]);
            else
                break;
        }
        if (j > pierwszy)
            sortuj_q(tablica, pierwszy, j);
        if (i < ostatni)
            sortuj_q(tablica, i, ostatni);
        return 0;
    }
template <int rozmiar1>
int sortowanie_przez_quicksort(int *wektor[rozmiar1])
{
    clock_t start, stop;
    start = clock();
    for (int i = 0; i < 100; i++)
    {
        sortuj_q(wektor[i], 0, rozmiar1 - 1);
    }
    stop = clock();
    unsigned long int czas = 1000 * (stop - start) / CLOCKS_PER_SEC;
    return czas;
}

#endif



