#ifndef SCALANIE_HH
#define SCALANIE_HH

#include <vector>
#include <iostream>
#include <math.h>
#include <memory>
#include <ctime>

using namespace std;

template <int rozmiar1>
void scal_tablice(int tablica[rozmiar1], int pierwszy, int srodek, int ostatni)
{
    // int *wektor_posortowany;
    // wektor_posortowany = new int[rozmiar1];
    int wektor_posortowany[rozmiar1];
    int i = pierwszy, j = srodek + 1;
    for (int i = pierwszy; i <= ostatni; i++)
        wektor_posortowany[i] = tablica[i]; // tworze tablice pomocnicza

    for (int k = pierwszy; k <= ostatni; k++)
    {
        if (i <= srodek)
            if (j <= ostatni)
                if (wektor_posortowany[j] < wektor_posortowany[i])
                    tablica[k] = wektor_posortowany[j++];
                else
                    tablica[k] = wektor_posortowany[i++];
            else
                tablica[k] = wektor_posortowany[i++];
        else
            tablica[k] = wektor_posortowany[j++];
    }
    // for (int i = 0; i <= rozmiar1; i++)
    // {
    //     wektor_posortowany[i] = tablica[i]; // tworze tablice pomocnicza
    // }
}
template <int rozmiar1>
int sortuj_s(int tablica[rozmiar1], int pierwszy, int ostatni)
{
    if (ostatni <= pierwszy)
    {
        return 0;
    }
    int srodek = (pierwszy + ostatni) / 2;

    sortuj_s<rozmiar1>(tablica, pierwszy, srodek);
    sortuj_s<rozmiar1>(tablica, srodek + 1, ostatni);

    scal_tablice<rozmiar1>(tablica, pierwszy, srodek, ostatni);
    return 0;
}
template <int rozmiar1>
int sortowanie_przez_scalanie(int *wektor[rozmiar1])
{
    clock_t start, stop;
    start = clock();
    for (int i = 0; i < 100; i++)
    {
        sortuj_s<rozmiar1>(wektor[i], 0, rozmiar1 - 1);
    }
    stop = clock();
    unsigned long int czas = 1000 * (stop - start) / CLOCKS_PER_SEC;
    return czas;
}

#endif


