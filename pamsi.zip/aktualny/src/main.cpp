#include <vector>
#include <iostream>
#include <math.h>
#include <memory>
#include <iomanip>
#include "../inc/scalanie.hh"
#include "../inc/QuickSort.hh"
#include "../inc/Shella.hh"

void tworz(int **wektor, int zmienna)
{
    for (int i = 0; i < 100; i++)
    {
        wektor[i] = new int[zmienna];
        for (int j = 0; j < zmienna; j++)
        {
            wektor[i][j] = rand() % zmienna;
        }
    }
}
void zmienprocent(int **wektor,int **pom, int zmienna, float procent)
{
    for (int i = 0; i < 100; i++)
    {
        for (int j = zmienna * procent; j < zmienna; j++)
        {
            wektor[i][j] = pom[i][j] % zmienna;
        }
    }
}

void copy(int **wektor, int **pom, int zmienna)
{
    for (int i = 0; i < 100; i++)
    {
        pom[i] = new int[zmienna];
        for (int j = 0; j < zmienna; j++)
        {
            pom[i][j] = wektor[i][j];
        }
    }
}
void wypisz(int **wektor, int zmienna)
{
    for (int i = 0; i < 1; i++)
    {
        for (int j = 0; j < zmienna; j++)
        {
            cout << wektor[i][j] << endl;
        }
    }
}
void odwrotnesortowanie(int **posortowana, int **odwrocona, int zmienna)
{
    int k = zmienna;
    for (int i = 0; i < 100; i++)
    {
        odwrocona[i] = new int[zmienna];
        for (int j = 0; j < zmienna; j++)
        {
            odwrocona[i][j] = posortowana[i][--k];
        }
    }
}

int main()
{
    unsigned long int czas_s = 0;
    unsigned long int czas_q = 0;
    unsigned long int czas_sh = 0;
    const int a = 10000;
    const int b = 50000;
    const int c = 100000;
    const int d = 500000;
    const int e = 1000000;
    int k = 100;
    const int zmienna = 1000000;

    int **wektor = new int *[k];
    int **pom = new int *[k];
    int **posortowana = new int *[k];
    int **odwrotnie = new int *[k];
    int **pierwotny = new int *[k];

    tworz(wektor, zmienna);
    copy(wektor, pom, zmienna);
    copy(wektor, pierwotny, zmienna);
    //sortowanie dla tablic nie posortowanych
    if (k <= 120)
    {
        cout << "rozpoczynam sortowanie tablic nie posortowanych" << endl;
        cout << "rozpoczynam sortowanie przez scalanie" << endl;
        czas_s = sortowanie_przez_scalanie<zmienna>(wektor); //      sortowanie przez scalanie
        cout << "rozpoczynam sortowanie quicksort" << endl;
        copy(pom, wektor, zmienna);
        czas_q = sortowanie_przez_quicksort<zmienna>(wektor); //      sortowanie przez quicksort
        cout << "rozpoczynam sortowanie shella" << endl;
        copy(pom, wektor, zmienna);
        czas_sh = sortowanie_shella<zmienna>(wektor);

        cout << "dla " << k << " tablic o dlugosci " << zmienna << " elementow:" << endl;
        cout << "czas sortowania przez scalanie = " << czas_s << endl;
        cout << "czas sortowania quicksort = " << czas_q << endl;
        cout << "czas sortowania shella = " << czas_sh << endl
             << endl;
    }
    //sortowanie dla tablic posortowanych w x%
    const float ax = 0.25;
    const float bx = 0.5;
    const float cx = 0.75;
    const float dx = 0.95;
    const float ex = 0.99;
    const float fx = 0.997;
    const float procent = cx;
    copy(wektor, posortowana, zmienna);
    zmienprocent(wektor, pierwotny, zmienna, procent);
    copy(wektor, pom, zmienna);
    if (k <= 120)
    {
        cout << "rozpoczynam sortowanie tablic w " << procent * 100 << "% posortowanych" << endl;
        cout << "rozpoczynam sortowanie przez scalanie" << endl;
        czas_s = sortowanie_przez_scalanie<zmienna>(wektor); //      sortowanie przez scalanie
        cout << "rozpoczynam sortowanie quicksort" << endl;
        copy(pom, wektor, zmienna);
        czas_q = sortowanie_przez_quicksort<zmienna>(wektor); //      sortowanie przez quicksort
        cout << "rozpoczynam sortowanie shella" << endl;
        copy(pom, wektor, zmienna);
        czas_sh = sortowanie_shella<zmienna>(wektor);

        cout << "dla " << k << " tablic o dlugosci " << zmienna << " elementow, gdzie " << procent * 100 << "% liczb jest juz posortowanych " << endl;
        cout << "czas sortowania przez scalanie = " << czas_s << endl;
        cout << "czas sortowania quicksort = " << czas_q << endl;
        cout << "czas sortowania shella = " << czas_sh << endl
             << endl;
    }
    odwrotnesortowanie(posortowana, wektor, zmienna);
    copy(wektor, pom, zmienna);
    if (k <= 120)
    {
        cout << "rozpoczynam sortowanie tablic posortowanych od tyłu" << endl;
        cout << "rozpoczynam sortowanie przez scalanie" << endl;
        czas_s = sortowanie_przez_scalanie<zmienna>(wektor); //      sortowanie przez scalanie
        cout << "rozpoczynam sortowanie quicksort" << endl;
        copy(pom, wektor, zmienna);
        czas_q = sortowanie_przez_quicksort<zmienna>(wektor); //      sortowanie przez quicksort
        cout << "rozpoczynam sortowanie shella" << endl;
        copy(pom, wektor, zmienna);
        czas_sh = sortowanie_shella<zmienna>(wektor);

        cout << "dla " << k << " tablic o dlugosci " << zmienna << " elementow, gdzie liczby były posortowane w odwrotnej kolejnosci" << endl;
        cout << "czas sortowania przez scalanie = " << czas_s << endl;
        cout << "czas sortowania quicksort = " << czas_q << endl;
        cout << "czas sortowania shella = " << czas_sh << endl
             << endl;
    }
    return 0;

    delete [] wektor;
    delete [] pom;
    delete [] posortowana;
    delete [] odwrotnie;
}
